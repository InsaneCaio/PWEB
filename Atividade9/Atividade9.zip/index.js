let array = [3];

for (let i = 0; i < 3; i++){
    array[i] = prompt("Digite o " + (i+1) + "o valor:");
}

alert("Maior valor: \n" + maiorVal(array));

alert("Ordem crescente: \n" + ordemCresc(array));

let palavra = prompt("Escreva a palavra: ");
palindromo(palavra);

palavra = prompt("Escreva a palavra principal: ");
let subPalavra = prompt("Escreva a palavra à ser procurada: ");
subconjunto(palavra, subPalavra);

function maiorVal(a) {
    return Math.max(...a);
}

function ordemCresc(a) {
    return a.sort((a, b) => a - b);
}

function palindromo(str) {
    if (str == str.split("").reverse().join(""))
        alert("Palavra palindroma");
    else
        alert("Palavra não palindroma");
}

function subconjunto(str, subStr){
    if (str.includes(subStr))
        alert("é um subconjunto");
    else
        alert("não é um subconjunto");
}

let data = prompt("Digite uma data (mm-dd-aaaa): ");

alert(diaSemana(data));

function diaSemana(dataString) {
  const dias = [
    'Domingo',
    'Segunda-feira',
    'Terça-feira',
    'Quarta-feira',
    'Quinta-feira',
    'Sexta-feira',
    'Sábado'
  ];
  
  const data = new Date(dataString);
  const indice = data.getDay();
  
  return dias[indice];
}