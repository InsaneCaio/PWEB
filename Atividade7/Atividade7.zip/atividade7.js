var vitPlayer = 0;
var vitMaquina = 0;

let escolhaPlayer = prompt("Escolha sua jogada\n1 - Pedra\n2 - Papel\n3 - Tesoura\n0 - Sair");

while (escolhaPlayer != 0) {
    let escolhaMaquina = Math.random();

    if (escolhaMaquina <= 0.33)
        escolhaMaquina = 1;
    else if (escolhaMaquina <= 0.66)
        escolhaMaquina = 2;
    else
        escolhaMaquina = 3;

    alert("Jogada da maquina >> " + escolhaMaquina);

    if (escolhaMaquina == escolhaPlayer)
        alert("Empate");
    else if ((escolhaPlayer == "3" && escolhaMaquina == "2") || (escolhaPlayer == "2" && escolhaMaquina == "1") || escolhaPlayer == "1" && escolhaMaquina == "3"){
        alert("Vitoria");
        vitPlayer++;
    }
    else{
        alert("Derrota");
        vitMaquina++;
    }

    alert("Placar atual\nVocê " + vitPlayer + " - " + vitMaquina + " Computador");

    escolhaPlayer = prompt("Escolha sua jogada\n1 - Pedra\n2 - Papel\n3 - Tesoura\n0 - Sair");
} 
