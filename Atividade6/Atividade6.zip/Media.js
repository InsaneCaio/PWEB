let nome = prompt("Digite seu nome")
var notas = 0;

for (let i = 0; i < 4; i++){
    notas += parseFloat(prompt("Digite a " + (i+1) + "ª nota"))
}

var media = notas / 4

alert("Média final do aluno " + nome + ": " + media.toFixed(2))