var num1 = parseFloat(prompt("Digite o primero numero"))
var num2 = parseFloat(prompt("Digite o segundo numero"))

alert(num1 + " + " + num2 + "= " + (num1+num2))
alert(num1 + " - " + num2 + "= " + (num1-num2))
alert(num1 + " * " + num2 + "= " + (num1*num2))
alert(num1 + " / " + num2 + "= " + (num1/num2))
alert("Resto da divisão " + num1 + " / " + num2 + "= " + (num1%num2))